--====================================================================
-- PACTICS Machine Documents — Load catalog files (model-scoped)
--====================================================================
-- Auto-detects the real folder name (Library / library) from storage,
-- then links each PDF to its model(s). Safe to re-run.
--====================================================================

do $$
declare folder text;
begin
  -- find the folder these files were uploaded into (case-exact from storage)
  select split_part(name,'/',1) into folder
    from storage.objects
    where bucket_id='catalogs' and name ilike '%gc6180.pdf'
    limit 1;
  if folder is null then
    raise exception 'Could not find gc6180.pdf in the catalogs bucket. Upload the files first.';
  end if;

  delete from public.documents where file_path like 'catalogs/%';

  insert into public.documents (scope, model, doc_type, title, file_path, file_name, mime, uploaded_by) values

    ('model', 'GC6180', 'catalog', 'Typical GC6180 Catalog', 'catalogs/'||folder||'/'||'gc6180.pdf', 'gc6180.pdf', 'application/pdf', 'Catalog import'),
    ('model', 'GC6890(MD4)', 'catalog', 'Typical GC6890(MD4) Catalog', 'catalogs/'||folder||'/'||'gc6890-md4.pdf', 'gc6890-md4.pdf', 'application/pdf', 'Catalog import'),
    ('model', 'JK-T1900GSK-D', 'catalog', 'Jack JK-T1900GSK-D Bartack Catalog', 'catalogs/'||folder||'/'||'bartack_jk-t1900gsk-d.pdf', 'bartack_jk-t1900gsk-d.pdf', 'application/pdf', 'Catalog import'),
    ('model', 'A2s', 'catalog', 'Jack A2s Lockstitch Catalog', 'catalogs/'||folder||'/'||'jack-a2s-lockstitch-sewing-machine.pdf', 'jack-a2s-lockstitch-sewing-machine.pdf', 'application/pdf', 'Catalog import'),
    ('model', 'A7', 'catalog', 'Jack A7 Catalog', 'catalogs/'||folder||'/'||'a7.pdf', 'a7.pdf', 'application/pdf', 'Catalog import'),
    ('model', 'A5E', 'catalog', 'Jack A5E Catalog', 'catalogs/'||folder||'/'||'a5e.pdf', 'a5e.pdf', 'application/pdf', 'Catalog import'),
    ('model', 'A4B', 'catalog', 'Jack A4B Catalog', 'catalogs/'||folder||'/'||'jack_a4b.pdf', 'jack_a4b.pdf', 'application/pdf', 'Catalog import'),
    ('model', 'A6F', 'catalog', 'Jack A6F Catalog', 'catalogs/'||folder||'/'||'instrukcja-jack-a6f.pdf', 'instrukcja-jack-a6f.pdf', 'application/pdf', 'Catalog import'),
    ('model', 'C6', 'catalog', 'Jack C6 Overlock Catalog', 'catalogs/'||folder||'/'||'jack_overlock_c6.pdf', 'jack_overlock_c6.pdf', 'application/pdf', 'Catalog import'),
    ('model', 'PS800(13085)', 'catalog', 'JUKI PS800-13085 Instruction', 'catalogs/'||folder||'/'||'instruction_juki_ps800-13085.pdf', 'instruction_juki_ps800-13085.pdf', 'application/pdf', 'Catalog import'),
    ('model', 'PS-800-8045', 'catalog', 'JUKI PS800-8045 Catalog', 'catalogs/'||folder||'/'||'juki_ps800-8045.pdf', 'juki_ps800-8045.pdf', 'application/pdf', 'Catalog import'),
    ('model', 'LK-1900B-SS', 'catalog', 'JUKI LK-1900B Bartack Catalog', 'catalogs/'||folder||'/'||'juki_bartack_lk-1900b.pdf', 'juki_bartack_lk-1900b.pdf', 'application/pdf', 'Catalog import'),
    ('model', 'C5', 'catalog', 'Jack C5 Overlock Catalog', 'catalogs/'||folder||'/'||'overlock_c5s.pdf', 'overlock_c5s.pdf', 'application/pdf', 'Catalog import'),
    ('model', 'A2s', 'catalog', 'Jack Spare Parts Catalog (general)', 'catalogs/'||folder||'/'||'jack-spare-parts-catalog.pdf', 'jack-spare-parts-catalog.pdf', 'application/pdf', 'Catalog import'),
    ('model', 'A3', 'catalog', 'Jack Spare Parts Catalog (general)', 'catalogs/'||folder||'/'||'jack-spare-parts-catalog.pdf', 'jack-spare-parts-catalog.pdf', 'application/pdf', 'Catalog import'),
    ('model', 'A4', 'catalog', 'Jack Spare Parts Catalog (general)', 'catalogs/'||folder||'/'||'jack-spare-parts-catalog.pdf', 'jack-spare-parts-catalog.pdf', 'application/pdf', 'Catalog import'),
    ('model', 'A4B', 'catalog', 'Jack Spare Parts Catalog (general)', 'catalogs/'||folder||'/'||'jack-spare-parts-catalog.pdf', 'jack-spare-parts-catalog.pdf', 'application/pdf', 'Catalog import'),
    ('model', 'A5E', 'catalog', 'Jack Spare Parts Catalog (general)', 'catalogs/'||folder||'/'||'jack-spare-parts-catalog.pdf', 'jack-spare-parts-catalog.pdf', 'application/pdf', 'Catalog import'),
    ('model', 'A5E-B', 'catalog', 'Jack Spare Parts Catalog (general)', 'catalogs/'||folder||'/'||'jack-spare-parts-catalog.pdf', 'jack-spare-parts-catalog.pdf', 'application/pdf', 'Catalog import'),
    ('model', 'A6F', 'catalog', 'Jack Spare Parts Catalog (general)', 'catalogs/'||folder||'/'||'jack-spare-parts-catalog.pdf', 'jack-spare-parts-catalog.pdf', 'application/pdf', 'Catalog import'),
    ('model', 'A7', 'catalog', 'Jack Spare Parts Catalog (general)', 'catalogs/'||folder||'/'||'jack-spare-parts-catalog.pdf', 'jack-spare-parts-catalog.pdf', 'application/pdf', 'Catalog import'),
    ('model', 'C5', 'catalog', 'Jack Spare Parts Catalog (general)', 'catalogs/'||folder||'/'||'jack-spare-parts-catalog.pdf', 'jack-spare-parts-catalog.pdf', 'application/pdf', 'Catalog import'),
    ('model', 'C6', 'catalog', 'Jack Spare Parts Catalog (general)', 'catalogs/'||folder||'/'||'jack-spare-parts-catalog.pdf', 'jack-spare-parts-catalog.pdf', 'application/pdf', 'Catalog import'),
    ('model', 'JK-2248', 'catalog', 'Jack Spare Parts Catalog (general)', 'catalogs/'||folder||'/'||'jack-spare-parts-catalog.pdf', 'jack-spare-parts-catalog.pdf', 'application/pdf', 'Catalog import'),
    ('model', 'JK-22848', 'catalog', 'Jack Spare Parts Catalog (general)', 'catalogs/'||folder||'/'||'jack-spare-parts-catalog.pdf', 'jack-spare-parts-catalog.pdf', 'application/pdf', 'Catalog import'),
    ('model', 'JK-5559G-W', 'catalog', 'Jack Spare Parts Catalog (general)', 'catalogs/'||folder||'/'||'jack-spare-parts-catalog.pdf', 'jack-spare-parts-catalog.pdf', 'application/pdf', 'Catalog import'),
    ('model', 'JK-58750J-403E', 'catalog', 'Jack Spare Parts Catalog (general)', 'catalogs/'||folder||'/'||'jack-spare-parts-catalog.pdf', 'jack-spare-parts-catalog.pdf', 'application/pdf', 'Catalog import'),
    ('model', 'JK-T1900GSK-D', 'catalog', 'Jack Spare Parts Catalog (general)', 'catalogs/'||folder||'/'||'jack-spare-parts-catalog.pdf', 'jack-spare-parts-catalog.pdf', 'application/pdf', 'Catalog import'),
    ('model', 'JK-T190GK-1-D', 'catalog', 'Jack Spare Parts Catalog (general)', 'catalogs/'||folder||'/'||'jack-spare-parts-catalog.pdf', 'jack-spare-parts-catalog.pdf', 'application/pdf', 'Catalog import');

  raise notice 'Loaded catalog links using folder: %', folder;
end $$;

-- Verify:
-- select model, file_path from public.documents where file_path like 'catalogs/%' order by model limit 40;
