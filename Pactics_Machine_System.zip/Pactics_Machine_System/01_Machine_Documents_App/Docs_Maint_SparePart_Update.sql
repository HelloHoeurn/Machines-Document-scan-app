--====================================================================
-- PACTICS Machine Documents — Spare parts + Maintenance update
--====================================================================
-- 1) Spare parts: add replacement date + who replaced it
-- 2) Maintenance schedule: redesign to mechanic-checklist format
--    (date done, type, line, mechanic, check items, remarks, next due)
-- Run in the 'Pactics Machine Docs' project. Safe to re-run.
--====================================================================

-- 1. Spare parts: new columns --------------------------------------
alter table public.spare_parts
  add column if not exists replaced_date date,
  add column if not exists replaced_by   text;

-- 2. Maintenance schedule: new columns -----------------------------
-- keep existing rows working; add the checklist fields.
alter table public.maintenance_schedule
  add column if not exists date_done   date,
  add column if not exists maint_type  text default 'monthly',   -- monthly | weekly
  add column if not exists line        text,
  add column if not exists mechanic    text,
  add column if not exists checks      jsonb default '[]'::jsonb; -- ['clean_oil','spare_parts',...]

-- (existing columns task, frequency, last_done, next_due, notes stay;
--  the app now uses date_done/mechanic/checks and keeps next_due + notes.)

-- Verify:
-- select column_name from information_schema.columns
--   where table_name='maintenance_schedule' order by ordinal_position;
