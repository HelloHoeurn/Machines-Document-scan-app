--====================================================================
-- PACTICS Machine Documents — Catalog files (add-on)
--====================================================================
-- Adds catalog/manual FILE attachments to the documents app.
--   * catalogs stored in Supabase Storage bucket 'catalogs'
--   * a 'documents' table records each file + what it attaches to
--   * attach PER MODEL (shows on all machines of that model) OR
--     PER MACHINE (override — shows only on that machine)
--
-- Run in the SAME 'Pactics Machine Docs' project. Safe to re-run.
--====================================================================

-- 1. Documents table -------------------------------------------------
-- scope='model'   -> applies to every machine with this model
-- scope='machine' -> applies only to this machine_code (override)
create table if not exists public.documents (
  id            bigint generated always as identity primary key,
  scope         text not null check (scope in ('model','machine')),
  model         text,          -- filled when scope='model'
  machine_code  text,          -- filled when scope='machine'
  doc_type      text not null default 'catalog'
                check (doc_type in ('catalog','manual','other')),
  title         text not null,
  file_path     text not null, -- path inside the storage bucket
  file_name     text,          -- original filename
  mime          text,
  size_bytes    bigint,
  uploaded_at   timestamptz not null default now(),
  uploaded_by   text
);
create index if not exists idx_doc_model   on public.documents(model);
create index if not exists idx_doc_machine on public.documents(machine_code);

alter table public.documents enable row level security;
drop policy if exists "rw documents" on public.documents;
create policy "rw documents" on public.documents for all to anon using (true) with check (true);

do $$ begin
  if not exists (select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='documents') then
    alter publication supabase_realtime add table public.documents; end if;
end $$;

-- 2. Storage bucket + policies ---------------------------------------
-- Create a public bucket named 'catalogs' (public = files viewable by link).
insert into storage.buckets (id, name, public)
  values ('catalogs','catalogs', true)
  on conflict (id) do update set public = true;

-- Allow the anon role to read/upload/update/delete objects in this bucket.
drop policy if exists "catalogs read"   on storage.objects;
drop policy if exists "catalogs insert" on storage.objects;
drop policy if exists "catalogs update" on storage.objects;
drop policy if exists "catalogs delete" on storage.objects;
create policy "catalogs read"   on storage.objects for select to anon using (bucket_id='catalogs');
create policy "catalogs insert" on storage.objects for insert to anon with check (bucket_id='catalogs');
create policy "catalogs update" on storage.objects for update to anon using (bucket_id='catalogs');
create policy "catalogs delete" on storage.objects for delete to anon using (bucket_id='catalogs');

-- Verify:
--   select * from storage.buckets where id='catalogs';
--   select count(*) from public.documents;
